import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Google GenAI client lazily or on route call
function getGenAI() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn('GEMINI_API_KEY environment variable is not defined.');
  }
  return new GoogleGenAI({
    apiKey: apiKey || 'dummy-key-for-dev',
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// AI Health Chat endpoint using Gemini 3.6 Flash
app.post('/api/health/chat', async (req, res) => {
  try {
    const { messages, userContext } = req.body;

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Messages array is required' });
    }

    const ai = getGenAI();

    // Context string building
    let systemContext = `You are VitalPulse AI, an empathetic, clear, and highly knowledgeable personal Health Assistant.
Your goal is to answer health, wellness, nutrition, fitness, sleep, and lifestyle questions.

IMPORTANT MEDICAL DISCLAIMER RULE:
- You must always provide accurate, educational, and evidence-based health information.
- ALWAYS maintain a compassionate, supportive, and non-judgmental tone.
- NEVER attempt to provide a definitive medical diagnosis, prescribe medication doses, or replace a doctor's care.
- Structure your answers with clear headings, bullet points, and high readability.
- When relevant, explicitly outline warning signs ("Red Flags") when the user should seek immediate emergency medical care.`;

    if (userContext) {
      systemContext += `\n\nUSER PROFILE CONTEXT:
- Age: ${userContext.age || 'Not specified'}
- Gender: ${userContext.gender || 'Not specified'}
- Height: ${userContext.height ? `${userContext.height} cm` : 'Not specified'}
- Weight: ${userContext.weight ? `${userContext.weight} kg` : 'Not specified'}
- BMI: ${userContext.bmi ? `${userContext.bmi} (${userContext.bmiCategory || ''})` : 'Not calculated'}
- Known Conditions / Allergies: ${userContext.conditions || 'None listed'}
Please tailor your health guidance sensitively to this profile context if relevant.`;
    }

    // Format chat history for Gemini
    const lastMessage = messages[messages.length - 1]?.content || '';
    const conversationHistory = messages.slice(0, -1).map(m => `${m.role === 'user' ? 'User' : 'VitalPulse AI'}: ${m.content}`).join('\n');

    const fullPrompt = `${conversationHistory ? `Previous Conversation:\n${conversationHistory}\n\n` : ''}User Question: ${lastMessage}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: fullPrompt,
      config: {
        systemInstruction: systemContext,
        temperature: 0.7,
      },
    });

    const replyText = response.text || 'I am sorry, I could not process your health question at this moment. Please try again.';

    res.json({
      reply: replyText,
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error('Error in /api/health/chat:', err);
    res.status(500).json({
      error: 'Failed to generate AI health response',
      message: err?.message || 'Internal server error',
    });
  }
});

// AI Daily Health Tip Generator
app.post('/api/health/daily-tip', async (req, res) => {
  try {
    const { category, userStats } = req.body;
    const ai = getGenAI();

    const prompt = `Generate a fresh, highly actionable, inspiring daily health & wellness tip for the category "${category || 'General Health'}".
${userStats ? `User context: Water intake today: ${userStats.waterLog || 0}ml, BMI: ${userStats.bmi || 'Normal'}.` : ''}
Return a JSON object with:
- "title": short catchy title (3-6 words)
- "category": string
- "content": concise, practical advice (2-3 sentences)
- "actionStep": 1 single quick action the user can do right now today
- "icon": suggested icon name (e.g. Heart, Droplet, Dumbbell, Sun, Moon, Apple)`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const jsonText = response.text || '{}';
    let tipData = {};
    try {
      tipData = JSON.parse(jsonText);
    } catch {
      tipData = {
        title: 'Stay Hydrated & Move Daily',
        category: category || 'Wellness',
        content: 'Drinking adequate water throughout the day enhances cognitive function, digestion, and physical stamina.',
        actionStep: 'Drink a full glass of water right now and stretch for 2 minutes!',
        icon: 'Droplet',
      };
    }

    res.json(tipData);
  } catch (err: any) {
    console.error('Error generating tip:', err);
    res.status(500).json({
      error: 'Failed to generate daily tip',
      message: err?.message,
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`VitalPulse AI Health Assistant running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
