import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Droplet, Plus, RefreshCw, Trophy, Flame, CheckCircle, Volume2 } from 'lucide-react';
import { useHealthData } from '../providers/HealthDataProvider';

export const WaterScreen: React.FC = () => {
  const { waterLog, addWaterEntry, updateWaterGoal, resetWaterLog } = useHealthData();
  const [customAmount, setCustomAmount] = useState<number>(250);
  const [isEditingGoal, setIsEditingGoal] = useState<boolean>(false);
  const [tempGoal, setTempGoal] = useState<number>(waterLog.goalMl || 2500);

  const percent = Math.min(100, Math.round((waterLog.totalMl / (waterLog.goalMl || 2500)) * 100));

  const handleGoalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateWaterGoal(tempGoal);
    setIsEditingGoal(false);
  };

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-6">
      {/* Title Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Droplet className="w-6 h-6 text-cyan-500 animate-bounce" />
            Water Hydration Tracker
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Monitor daily fluid balance & reach optimal hydration
          </p>
        </div>
        <button
          onClick={resetWaterLog}
          className="p-2 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-cyan-600 transition-colors"
          title="Reset Today's Water Log"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Animated Water Cylinder Card */}
        <div className="rounded-3xl p-6 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col items-center justify-center text-center relative overflow-hidden">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">
            Today's Hydration Progress
          </span>
          <div className="text-4xl font-extrabold text-slate-900 dark:text-slate-100 my-1">
            {waterLog.totalMl} <span className="text-lg text-slate-400 font-normal">/ {waterLog.goalMl} ml</span>
          </div>

          {/* Animated Liquid Cylinder Container */}
          <div className="relative w-40 h-56 rounded-3xl bg-cyan-50 dark:bg-cyan-950/40 border-4 border-cyan-200 dark:border-cyan-800/80 overflow-hidden shadow-inner my-4 flex items-end">
            <motion.div
              initial={{ height: '0%' }}
              animate={{ height: `${percent}%` }}
              transition={{ duration: 0.8, ease: 'easeOut' }}
              className="w-full bg-gradient-to-t from-cyan-600 to-blue-400 relative flex items-center justify-center"
            >
              {/* Wave SVG Animation overlay */}
              <div className="absolute top-0 left-0 right-0 h-4 -mt-2 bg-cyan-400/50 rounded-full animate-pulse" />
              <div className="text-white font-extrabold text-xl shadow-sm z-10">{percent}%</div>
            </motion.div>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300 font-semibold mt-1">
            {percent >= 100 ? (
              <span className="text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <Trophy className="w-4 h-4 text-amber-500" /> Goal Completed! Keep it up!
              </span>
            ) : (
              <span>{waterLog.goalMl - waterLog.totalMl} ml needed to reach goal</span>
            )}
          </div>

          {/* Edit Goal Toggle */}
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 w-full text-center">
            {isEditingGoal ? (
              <form onSubmit={handleGoalSubmit} className="flex items-center justify-center gap-2 max-w-xs mx-auto">
                <input
                  type="number"
                  step="100"
                  min="500"
                  max="5000"
                  value={tempGoal}
                  onChange={e => setTempGoal(Number(e.target.value))}
                  className="w-28 px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-slate-100"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 rounded-xl bg-cyan-600 text-white font-semibold text-xs"
                >
                  Save Goal
                </button>
              </form>
            ) : (
              <button
                onClick={() => setIsEditingGoal(true)}
                className="text-xs text-cyan-600 dark:text-cyan-400 hover:underline"
              >
                Change Daily Goal ({waterLog.goalMl} ml)
              </button>
            )}
          </div>
        </div>

        {/* Quick Add Buttons & Timeline Logs */}
        <div className="space-y-4">
          <div className="rounded-3xl p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Quick Add Water Intake
            </h3>

            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => addWaterEntry(250)}
                className="p-3 rounded-2xl bg-cyan-50 dark:bg-cyan-950/40 hover:bg-cyan-100 dark:hover:bg-cyan-900/50 border border-cyan-200 dark:border-cyan-800 text-cyan-800 dark:text-cyan-300 text-xs font-semibold flex flex-col items-center justify-center gap-1 transition-all active:scale-95"
              >
                <Droplet className="w-5 h-5 text-cyan-500" />
                <span>+250 ml</span>
                <span className="text-[10px] text-slate-400 font-normal">Glass</span>
              </button>
              <button
                onClick={() => addWaterEntry(500)}
                className="p-3 rounded-2xl bg-cyan-50 dark:bg-cyan-950/40 hover:bg-cyan-100 dark:hover:bg-cyan-900/50 border border-cyan-200 dark:border-cyan-800 text-cyan-800 dark:text-cyan-300 text-xs font-semibold flex flex-col items-center justify-center gap-1 transition-all active:scale-95"
              >
                <Droplet className="w-5 h-5 text-blue-500" />
                <span>+500 ml</span>
                <span className="text-[10px] text-slate-400 font-normal">Bottle</span>
              </button>
              <button
                onClick={() => addWaterEntry(750)}
                className="p-3 rounded-2xl bg-cyan-50 dark:bg-cyan-950/40 hover:bg-cyan-100 dark:hover:bg-cyan-900/50 border border-cyan-200 dark:border-cyan-800 text-cyan-800 dark:text-cyan-300 text-xs font-semibold flex flex-col items-center justify-center gap-1 transition-all active:scale-95"
              >
                <Droplet className="w-5 h-5 text-indigo-500" />
                <span>+750 ml</span>
                <span className="text-[10px] text-slate-400 font-normal">Large Flask</span>
              </button>
            </div>

            {/* Custom Amount */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2">
              <input
                type="number"
                step="50"
                value={customAmount}
                onChange={e => setCustomAmount(Number(e.target.value))}
                placeholder="Custom ml"
                className="flex-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-slate-100"
              />
              <button
                onClick={() => addWaterEntry(customAmount)}
                className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-semibold text-xs flex items-center gap-1 transition-all shadow-md shadow-cyan-600/20 active:scale-95 shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>Add {customAmount} ml</span>
              </button>
            </div>
          </div>

          {/* Today's Intake Entries Log */}
          <div className="rounded-3xl p-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
              Today's Intake Log Timeline
            </h3>

            {waterLog.entries.length === 0 ? (
              <p className="text-xs text-slate-400 py-4 text-center">No water intake logged yet today.</p>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {waterLog.entries.map(entry => (
                  <div
                    key={entry.id}
                    className="flex items-center justify-between p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 text-xs border border-slate-100 dark:border-slate-800"
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-xl bg-cyan-100 dark:bg-cyan-950 text-cyan-600 flex items-center justify-center">
                        <Droplet className="w-3.5 h-3.5" />
                      </div>
                      <span className="font-bold text-slate-900 dark:text-slate-100">+{entry.amountMl} ml</span>
                    </div>
                    <span className="text-[10px] text-slate-400">{entry.timestamp}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
