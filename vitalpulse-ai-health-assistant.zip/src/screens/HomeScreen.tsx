import React from 'react';
import { motion } from 'motion/react';
import {
  Activity,
  Droplet,
  Pill,
  Calculator,
  Bot,
  Sparkles,
  CheckCircle2,
  Clock,
  ArrowRight,
  TrendingUp,
  Heart,
  Moon,
  Footprints,
  Bookmark,
} from 'lucide-react';
import { useHealthData } from '../providers/HealthDataProvider';
import { useAuth } from '../providers/AuthProvider';
import { ScreenTab } from '../widgets/Navbar';
import { HealthCard } from '../widgets/HealthCard';

interface HomeScreenProps {
  setActiveTab: (tab: ScreenTab) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({ setActiveTab }) => {
  const { user } = useAuth();
  const {
    waterLog,
    addWaterEntry,
    medications,
    toggleMedicineTaken,
    bmiHistory,
    tips,
    bookmarkedIds,
    toggleBookmarkTip,
    healthScore,
  } = useHealthData();

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  const currentBmi = bmiHistory[0];

  const pendingMeds = medications.filter(m => !m.takenToday && m.active);
  const featuredTip = tips[0];

  const waterPercent = Math.min(100, Math.round((waterLog.totalMl / (waterLog.goalMl || 2500)) * 100));

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-5">
      {/* Welcome Hero Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        className="rounded-3xl p-5 sm:p-6 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 text-white shadow-lg shadow-teal-500/20 relative overflow-hidden"
      >
        <div className="absolute -right-6 -bottom-6 w-36 h-36 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-emerald-100 text-xs font-semibold uppercase tracking-wider mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{getGreeting()}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Hello, {user?.name || 'Friend'}!
            </h1>
            <p className="text-emerald-50 text-xs sm:text-sm mt-1 max-w-md opacity-90">
              Your AI health companion is active. Here is your personalized daily wellness summary.
            </p>
          </div>

          {/* AI Health Score Circular Gauge */}
          <div className="flex items-center gap-3 bg-white/15 backdrop-blur-md p-3.5 rounded-2xl border border-white/20 shrink-0 self-start sm:self-auto">
            <div className="relative w-14 h-14 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90">
                <circle cx="28" cy="28" r="22" stroke="currentColor" strokeWidth="4" className="text-white/20" fill="transparent" />
                <circle
                  cx="28"
                  cy="28"
                  r="22"
                  stroke="currentColor"
                  strokeWidth="4"
                  className="text-white transition-all duration-1000"
                  fill="transparent"
                  strokeDasharray={138}
                  strokeDashoffset={138 - (138 * healthScore) / 100}
                  strokeLinecap="round"
                />
              </svg>
              <span className="absolute font-bold text-base">{healthScore}</span>
            </div>
            <div>
              <div className="text-[11px] uppercase tracking-wider text-emerald-100 font-semibold">Health Score</div>
              <div className="text-xs font-medium text-white">
                {healthScore >= 80 ? 'Excellent Status' : healthScore >= 60 ? 'Good Progress' : 'Needs Hydration'}
              </div>
            </div>
          </div>
        </div>

        {/* Quick Action Chips */}
        <div className="mt-5 pt-4 border-t border-white/20 flex flex-wrap gap-2 text-xs">
          <button
            onClick={() => setActiveTab('chat')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white text-teal-800 font-semibold shadow-sm hover:bg-emerald-50 transition-all active:scale-95"
          >
            <Bot className="w-3.5 h-3.5 text-teal-600" />
            <span>Ask AI Doctor</span>
          </button>
          <button
            onClick={() => setActiveTab('water')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white font-medium backdrop-blur-sm transition-all active:scale-95"
          >
            <Droplet className="w-3.5 h-3.5" />
            <span>Log Water</span>
          </button>
          <button
            onClick={() => setActiveTab('bmi')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white font-medium backdrop-blur-sm transition-all active:scale-95"
          >
            <Calculator className="w-3.5 h-3.5" />
            <span>Calculate BMI</span>
          </button>
        </div>
      </motion.div>

      {/* Main Health Dashboard Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Hydration Card */}
        <HealthCard
          title="Daily Hydration"
          subtitle={`${waterLog.totalMl} / ${waterLog.goalMl} ml logged`}
          actionIcon={<ArrowRight className="w-4 h-4" />}
          onAction={() => setActiveTab('water')}
        >
          <div className="flex items-center gap-4 mt-2">
            <div className="relative w-16 h-16 rounded-2xl bg-cyan-50 dark:bg-cyan-950/50 border border-cyan-200 dark:border-cyan-800 flex items-center justify-center shrink-0">
              <Droplet className="w-8 h-8 text-cyan-500 animate-bounce" />
              <span className="absolute bottom-1 text-[10px] font-bold text-cyan-700 dark:text-cyan-300">{waterPercent}%</span>
            </div>
            <div className="flex-1">
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-cyan-400 to-blue-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${waterPercent}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mt-2">
                <span>Goal: {waterLog.goalMl} ml</span>
                <span className="font-semibold text-cyan-600 dark:text-cyan-400">
                  {waterLog.goalMl - waterLog.totalMl > 0 ? `${waterLog.goalMl - waterLog.totalMl} ml remaining` : 'Target Met! 🎉'}
                </span>
              </div>
              <button
                onClick={() => addWaterEntry(250)}
                className="mt-3 w-full py-1.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-700 dark:text-cyan-300 font-semibold text-xs flex items-center justify-center gap-1 transition-colors"
              >
                + Quick Add 250ml Glass
              </button>
            </div>
          </div>
        </HealthCard>

        {/* Medicine Schedule Card */}
        <HealthCard
          title="Medication Reminder"
          subtitle={pendingMeds.length > 0 ? `${pendingMeds.length} pending today` : 'All medications taken today!'}
          actionIcon={<ArrowRight className="w-4 h-4" />}
          onAction={() => setActiveTab('medicine')}
        >
          {medications.length === 0 ? (
            <p className="text-xs text-slate-500 py-4 text-center">No medications scheduled.</p>
          ) : (
            <div className="space-y-2 mt-2">
              {medications.slice(0, 3).map(med => (
                <div
                  key={med.id}
                  className="flex items-center justify-between p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                      <Pill className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-semibold text-slate-900 dark:text-slate-100">{med.name}</h4>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400">{med.dosage} • {med.time}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => toggleMedicineTaken(med.id)}
                    className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all ${
                      med.takenToday
                        ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                        : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-emerald-500 hover:text-white'
                    }`}
                  >
                    {med.takenToday ? 'Taken ✓' : 'Take'}
                  </button>
                </div>
              ))}
            </div>
          )}
        </HealthCard>

        {/* BMI & Stats Card */}
        <HealthCard
          title="BMI & Body Metrics"
          subtitle={currentBmi ? `Last calculated: ${new Date(currentBmi.date).toLocaleDateString()}` : 'No BMI records yet'}
          actionIcon={<ArrowRight className="w-4 h-4" />}
          onAction={() => setActiveTab('bmi')}
        >
          <div className="flex items-center justify-between mt-2 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
            <div>
              <div className="text-xs text-slate-500 dark:text-slate-400">Current BMI</div>
              <div className="text-2xl font-bold text-slate-900 dark:text-slate-100">
                {currentBmi ? currentBmi.bmi : '--'}
              </div>
            </div>
            {currentBmi && (
              <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                currentBmi.category === 'normal'
                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                  : currentBmi.category === 'underweight'
                  ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                  : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
              }`}>
                {currentBmi.category}
              </span>
            )}
            <button
              onClick={() => setActiveTab('bmi')}
              className="px-3 py-1.5 rounded-xl bg-emerald-500 text-white font-semibold text-xs hover:bg-emerald-600 transition-colors"
            >
              Recalculate
            </button>
          </div>
        </HealthCard>

        {/* Activity & Sleep Goals Card */}
        <HealthCard title="Daily Activity & Rest" subtitle="Activity targets & sleep tracker">
          <div className="grid grid-cols-2 gap-2 mt-2">
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mb-1">
                <Footprints className="w-4 h-4 text-emerald-500" />
                <span>Daily Steps</span>
              </div>
              <div className="text-lg font-bold text-slate-900 dark:text-slate-100">6,420</div>
              <div className="text-[10px] text-slate-400 mt-0.5">Target: 8,000 steps</div>
            </div>
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mb-1">
                <Moon className="w-4 h-4 text-indigo-500" />
                <span>Sleep Rest</span>
              </div>
              <div className="text-lg font-bold text-slate-900 dark:text-slate-100">7.5 hrs</div>
              <div className="text-[10px] text-slate-400 mt-0.5">Target: 8.0 hrs</div>
            </div>
          </div>
        </HealthCard>
      </div>

      {/* Daily Health Tip Banner */}
      {featuredTip && (
        <HealthCard
          title="💡 Daily AI Health Tip"
          actionIcon={
            <button
              onClick={() => toggleBookmarkTip(featuredTip.id)}
              className="text-amber-500 hover:scale-110 transition-transform"
            >
              <Bookmark className={`w-4 h-4 ${bookmarkedIds.includes(featuredTip.id) ? 'fill-amber-500' : ''}`} />
            </button>
          }
        >
          <div className="mt-1">
            <h4 className="font-bold text-sm text-slate-900 dark:text-slate-100">{featuredTip.title}</h4>
            <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">{featuredTip.content}</p>
            <div className="mt-3 p-2.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-900 dark:text-emerald-200 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span><strong>Action:</strong> {featuredTip.actionStep}</span>
            </div>
          </div>
        </HealthCard>
      )}
    </div>
  );
};
