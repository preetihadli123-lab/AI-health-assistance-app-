import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Calculator, Scale, Ruler, History, Sparkles, CheckCircle, Save } from 'lucide-react';
import { useHealthData } from '../providers/HealthDataProvider';
import { useAuth } from '../providers/AuthProvider';
import { BmiCategoryType } from '../models';

export const BMIScreen: React.FC = () => {
  const { user } = useAuth();
  const { bmiHistory, addBmiRecord } = useHealthData();

  const [unitSystem, setUnitSystem] = useState<'metric' | 'imperial'>('metric');

  // Metric State
  const [heightCm, setHeightCm] = useState<number>(user?.heightCm || 175);
  const [weightKg, setWeightKg] = useState<number>(user?.weightKg || 68);

  // Imperial State
  const [feet, setFeet] = useState<number>(5);
  const [inches, setInches] = useState<number>(9);
  const [lbs, setLbs] = useState<number>(150);

  const [notes, setNotes] = useState<string>('');
  const [justSaved, setJustSaved] = useState<boolean>(false);

  // Calculate actual cm and kg values based on selected unit system
  const effectiveHeightCm =
    unitSystem === 'metric' ? heightCm : Math.round((feet * 12 + inches) * 2.54);
  const effectiveWeightKg = unitSystem === 'metric' ? weightKg : Number((lbs * 0.453592).toFixed(1));

  // Calculate BMI: weight (kg) / (height (m))^2
  const heightM = effectiveHeightCm / 100;
  const bmiValue = heightM > 0 ? Number((effectiveWeightKg / (heightM * heightM)).toFixed(1)) : 0;

  let category: BmiCategoryType = 'normal';
  let categoryLabel = 'Normal Weight';
  let categoryColor = 'bg-emerald-500 text-emerald-950 border-emerald-400';
  let categoryBg = 'from-emerald-500/10 to-teal-500/10 border-emerald-500/30';

  if (bmiValue < 18.5) {
    category = 'underweight';
    categoryLabel = 'Underweight';
    categoryColor = 'bg-amber-500 text-amber-950 border-amber-400';
    categoryBg = 'from-amber-500/10 to-orange-500/10 border-amber-500/30';
  } else if (bmiValue <= 24.9) {
    category = 'normal';
    categoryLabel = 'Normal Healthy Weight';
    categoryColor = 'bg-emerald-500 text-white border-emerald-400';
    categoryBg = 'from-emerald-500/10 to-teal-500/10 border-emerald-500/30';
  } else if (bmiValue <= 29.9) {
    category = 'overweight';
    categoryLabel = 'Overweight';
    categoryColor = 'bg-orange-500 text-white border-orange-400';
    categoryBg = 'from-orange-500/10 to-amber-500/10 border-orange-500/30';
  } else {
    category = 'obese';
    categoryLabel = 'Obese';
    categoryColor = 'bg-rose-500 text-white border-rose-400';
    categoryBg = 'from-rose-500/10 to-red-500/10 border-rose-500/30';
  }

  // Calculate Ideal Weight Range for current height
  const minIdealKg = Number((18.5 * heightM * heightM).toFixed(1));
  const maxIdealKg = Number((24.9 * heightM * heightM).toFixed(1));

  const handleSave = () => {
    addBmiRecord(effectiveHeightCm, effectiveWeightKg, notes);
    setNotes('');
    setJustSaved(true);
    setTimeout(() => setJustSaved(false), 3000);
  };

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-6">
      {/* Title Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Calculator className="w-6 h-6 text-emerald-500" />
            BMI Calculator
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Calculate Body Mass Index & track target health ranges
          </p>
        </div>

        {/* Unit Toggle Switch */}
        <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs">
          <button
            onClick={() => setUnitSystem('metric')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
              unitSystem === 'metric'
                ? 'bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-400 shadow-sm'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            Metric (cm/kg)
          </button>
          <button
            onClick={() => setUnitSystem('imperial')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
              unitSystem === 'imperial'
                ? 'bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-400 shadow-sm'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            Imperial (ft/lbs)
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Controls Card */}
        <div className="rounded-3xl p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5">
          {/* Height Input */}
          <div>
            <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
              <span className="flex items-center gap-1.5">
                <Ruler className="w-4 h-4 text-emerald-500" />
                Height
              </span>
              <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                {unitSystem === 'metric' ? `${heightCm} cm` : `${feet} ft ${inches} in`}
              </span>
            </div>

            {unitSystem === 'metric' ? (
              <div className="space-y-2">
                <input
                  type="range"
                  min="120"
                  max="220"
                  value={heightCm}
                  onChange={e => setHeightCm(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
                <input
                  type="number"
                  value={heightCm}
                  onChange={e => setHeightCm(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-slate-400">Feet</label>
                  <input
                    type="number"
                    min="3"
                    max="8"
                    value={feet}
                    onChange={e => setFeet(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400">Inches</label>
                  <input
                    type="number"
                    min="0"
                    max="11"
                    value={inches}
                    onChange={e => setInches(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Weight Input */}
          <div>
            <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
              <span className="flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-emerald-500" />
                Weight
              </span>
              <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                {unitSystem === 'metric' ? `${weightKg} kg` : `${lbs} lbs`}
              </span>
            </div>

            {unitSystem === 'metric' ? (
              <div className="space-y-2">
                <input
                  type="range"
                  min="30"
                  max="160"
                  value={weightKg}
                  onChange={e => setWeightKg(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
                <input
                  type="number"
                  value={weightKg}
                  onChange={e => setWeightKg(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            ) : (
              <div className="space-y-2">
                <input
                  type="range"
                  min="60"
                  max="350"
                  value={lbs}
                  onChange={e => setLbs(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
                <input
                  type="number"
                  value={lbs}
                  onChange={e => setLbs(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-slate-100"
                />
              </div>
            )}
          </div>

          {/* Save Note & Action */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
            <input
              type="text"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="Add optional note (e.g. Morning weigh-in)..."
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-slate-100"
            />
            <button
              onClick={handleSave}
              className="w-full py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-emerald-600/20 active:scale-95"
            >
              {justSaved ? <CheckCircle className="w-4 h-4" /> : <Save className="w-4 h-4" />}
              <span>{justSaved ? 'Saved to Health Log!' : 'Save BMI Record'}</span>
            </button>
          </div>
        </div>

        {/* BMI Results Gauge & Insights */}
        <div className="space-y-4">
          <motion.div
            key={bmiValue}
            initial={{ scale: 0.96, opacity: 0.8 }}
            animate={{ scale: 1, opacity: 1 }}
            className={`rounded-3xl p-6 bg-gradient-to-br ${categoryBg} border shadow-sm flex flex-col items-center text-center relative overflow-hidden`}
          >
            <span className="text-xs uppercase tracking-wider font-semibold text-slate-500 dark:text-slate-400">
              Your Calculated BMI
            </span>
            <div className="text-5xl font-extrabold text-slate-900 dark:text-slate-100 my-2 tracking-tight">
              {bmiValue}
            </div>

            <span className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase border ${categoryColor} shadow-sm`}>
              {categoryLabel}
            </span>

            {/* Visual Gauge Scale */}
            <div className="w-full mt-6 space-y-1">
              <div className="w-full h-3 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden flex">
                <div className="w-[18.5%] bg-amber-400" title="Underweight (< 18.5)" />
                <div className="w-[31.5%] bg-emerald-500" title="Normal (18.5 - 24.9)" />
                <div className="w-[25%] bg-orange-400" title="Overweight (25.0 - 29.9)" />
                <div className="w-[25%] bg-rose-500" title="Obese (30.0+)" />
              </div>
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>15.0</span>
                <span>18.5</span>
                <span>25.0</span>
                <span>30.0</span>
                <span>40.0</span>
              </div>
            </div>

            {/* Target Recommendation */}
            <div className="mt-5 pt-4 border-t border-slate-200/50 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300 w-full text-left space-y-1">
              <div className="flex items-center gap-1.5 font-semibold text-slate-900 dark:text-slate-100">
                <Sparkles className="w-4 h-4 text-emerald-500" />
                <span>Healthy Weight Target Range:</span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300">
                For a height of <strong>{effectiveHeightCm} cm</strong>, your normal healthy weight range is{' '}
                <span className="font-bold text-emerald-600 dark:text-emerald-400">
                  {minIdealKg} kg – {maxIdealKg} kg
                </span>.
              </p>
            </div>
          </motion.div>

          {/* BMI History Logs */}
          <div className="rounded-3xl p-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3 flex items-center gap-1.5">
              <History className="w-4 h-4 text-emerald-500" />
              Recent BMI Log History
            </h3>
            {bmiHistory.length === 0 ? (
              <p className="text-xs text-slate-400 py-3 text-center">No historical records saved.</p>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {bmiHistory.map(rec => (
                  <div
                    key={rec.id}
                    className="flex items-center justify-between p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 text-xs border border-slate-100 dark:border-slate-800"
                  >
                    <div>
                      <span className="font-bold text-slate-900 dark:text-slate-100">BMI {rec.bmi}</span>
                      <span className="text-[10px] text-slate-400 ml-2">({rec.weightKg} kg / {rec.heightCm} cm)</span>
                    </div>
                    <div className="text-[10px] text-slate-400">
                      {new Date(rec.date).toLocaleDateString()}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
