import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Bot,
  Send,
  Trash2,
  Sparkles,
  Volume2,
  VolumeX,
  Copy,
  Check,
  ShieldAlert,
  User,
  RefreshCw,
} from 'lucide-react';
import { useHealthData } from '../providers/HealthDataProvider';
import { HealthPrompt } from '../models';

const PRESET_PROMPTS: HealthPrompt[] = [
  {
    id: 'p1',
    title: 'Headache Relief',
    prompt: 'I have a mild tension headache. What are safe home remedies, hydration steps, and warning signs when to see a doctor?',
    category: 'symptom',
    icon: '🤕',
  },
  {
    id: 'p2',
    title: 'Energy Booster Foods',
    prompt: 'What are nutrient-dense whole foods to maintain consistent physical and mental energy throughout the afternoon?',
    category: 'nutrition',
    icon: '🥗',
  },
  {
    id: 'p3',
    title: 'Sleep Routine',
    prompt: 'Can you give me a step-by-step evening routine to fall asleep faster and improve REM sleep quality naturally?',
    category: 'sleep',
    icon: '🌙',
  },
  {
    id: 'p4',
    title: 'Cardio Workout Plan',
    prompt: 'What is a safe 20-minute beginner cardio routine for improving cardiovascular health and stamina?',
    category: 'fitness',
    icon: '🏃‍♂️',
  },
];

export const ChatScreen: React.FC = () => {
  const { chatMessages, isChatLoading, sendChatMessage, clearChatHistory } = useHealthData();
  const [inputText, setInputText] = useState<string>('');
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatMessages, isChatLoading]);

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim() || isChatLoading) return;
    const msg = inputText;
    setInputText('');
    await sendChatMessage(msg);
  };

  const handlePromptClick = (promptText: string) => {
    sendChatMessage(promptText);
  };

  const handleSpeech = (id: string, text: string) => {
    if (!('speechSynthesis' in window)) return;

    if (speakingMsgId === id) {
      window.speechSynthesis.cancel();
      setSpeakingMsgId(null);
      return;
    }

    window.speechSynthesis.cancel();
    // Strip markdown formatting symbols for speech
    const cleanText = text.replace(/[*#_`]/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    utterance.onend = () => setSpeakingMsgId(null);
    utterance.onerror = () => setSpeakingMsgId(null);

    setSpeakingMsgId(id);
    window.speechSynthesis.speak(utterance);
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-130px)] max-w-4xl mx-auto p-2 sm:p-4">
      {/* Prominent Medical Disclaimer Header */}
      <div className="bg-amber-500/10 dark:bg-amber-500/15 border border-amber-500/20 rounded-2xl p-3 mb-3 text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2.5 shrink-0">
        <ShieldAlert className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">Medical Disclaimer:</span> This AI assistant provides educational wellness information powered by Gemini. It does <strong>NOT</strong> provide medical diagnosis or replace consultation with a qualified doctor. In medical emergencies, call emergency services immediately.
        </div>
        <button
          onClick={clearChatHistory}
          className="ml-auto p-1.5 rounded-xl hover:bg-amber-200/50 dark:hover:bg-amber-900/40 text-amber-700 dark:text-amber-300 transition-colors"
          title="Clear Chat History"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto space-y-4 px-1 pr-2">
        <AnimatePresence initial={false}>
          {chatMessages.map(msg => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex items-start gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
            >
              {/* Avatar */}
              <div
                className={`w-9 h-9 rounded-2xl flex items-center justify-center shrink-0 shadow-sm ${
                  msg.role === 'user'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-gradient-to-tr from-teal-500 to-emerald-400 text-white'
                }`}
              >
                {msg.role === 'user' ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
              </div>

              {/* Message Box */}
              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-3xl p-4 text-xs sm:text-sm leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-emerald-600 text-white rounded-tr-none'
                    : 'bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-slate-900 dark:text-slate-100 shadow-sm rounded-tl-none'
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.content}</div>

                {/* Assistant Toolbar */}
                {msg.role === 'assistant' && (
                  <div className="flex items-center gap-2 mt-3 pt-2 border-t border-slate-100 dark:border-slate-800/80 text-slate-400">
                    <button
                      onClick={() => handleSpeech(msg.id, msg.content)}
                      className={`p-1 hover:text-emerald-500 transition-colors ${speakingMsgId === msg.id ? 'text-emerald-500 animate-pulse' : ''}`}
                      title="Listen to Voice"
                    >
                      {speakingMsgId === msg.id ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      onClick={() => handleCopy(msg.id, msg.content)}
                      className="p-1 hover:text-emerald-500 transition-colors"
                      title="Copy Answer"
                    >
                      {copiedId === msg.id ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                    <span className="text-[10px] text-slate-400 ml-auto">
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {isChatLoading && (
          <div className="flex items-center gap-3 text-slate-400 text-xs p-2">
            <div className="w-9 h-9 rounded-2xl bg-teal-500/20 text-teal-500 flex items-center justify-center animate-spin">
              <RefreshCw className="w-4 h-4" />
            </div>
            <span>VitalPulse AI is typing recommendations...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Preset Prompt Chips */}
      {chatMessages.length <= 2 && (
        <div className="py-2 flex gap-2 overflow-x-auto shrink-0 no-scrollbar">
          {PRESET_PROMPTS.map(p => (
            <button
              key={p.id}
              onClick={() => handlePromptClick(p.prompt)}
              className="px-3 py-1.5 rounded-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 hover:border-emerald-500 hover:text-emerald-600 transition-all shrink-0 flex items-center gap-1.5 shadow-sm"
            >
              <span>{p.icon}</span>
              <span>{p.title}</span>
            </button>
          ))}
        </div>
      )}

      {/* Input Bar */}
      <form onSubmit={handleSend} className="mt-2 flex items-center gap-2 shrink-0">
        <input
          type="text"
          value={inputText}
          onChange={e => setInputText(e.target.value)}
          placeholder="Ask any health, nutrition, or wellness question..."
          className="flex-1 px-4 py-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-sm transition-all"
        />
        <button
          type="submit"
          disabled={!inputText.trim() || isChatLoading}
          className="p-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-semibold transition-all shadow-md shadow-emerald-600/20 active:scale-95 shrink-0"
        >
          <Send className="w-5 h-5" />
        </button>
      </form>
    </div>
  );
};
