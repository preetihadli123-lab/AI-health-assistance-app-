import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Lightbulb, Bookmark, Sparkles, Search, CheckCircle2, RefreshCw, Heart, Moon, Dumbbell, Apple, Activity } from 'lucide-react';
import { useHealthData } from '../providers/HealthDataProvider';
import { TipCategory } from '../models';

export const TipsScreen: React.FC = () => {
  const { tips, bookmarkedIds, toggleBookmarkTip, generateAiTip, isGeneratingTip } = useHealthData();
  const [selectedCategory, setSelectedCategory] = useState<TipCategory>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showBookmarksOnly, setShowBookmarksOnly] = useState<boolean>(false);

  const categories: { id: TipCategory; label: string }[] = [
    { id: 'all', label: 'All Categories' },
    { id: 'nutrition', label: 'Nutrition' },
    { id: 'fitness', label: 'Fitness' },
    { id: 'mental', label: 'Mental' },
    { id: 'sleep', label: 'Sleep' },
    { id: 'heart', label: 'Heart' },
  ];

  const filteredTips = tips.filter(tip => {
    if (showBookmarksOnly && !bookmarkedIds.includes(tip.id)) return false;
    if (selectedCategory !== 'all' && tip.category !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        tip.title.toLowerCase().includes(q) ||
        tip.content.toLowerCase().includes(q) ||
        tip.actionStep.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-6">
      {/* Header & AI Tip Generator Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Lightbulb className="w-6 h-6 text-amber-500" />
            Daily Health & Wellness Tips
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Evidence-based advice & AI-personalized wellness habits
          </p>
        </div>

        <button
          onClick={() => generateAiTip(selectedCategory)}
          disabled={isGeneratingTip}
          className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 disabled:opacity-50 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-all shadow-md shadow-emerald-600/20 active:scale-95 shrink-0"
        >
          {isGeneratingTip ? (
            <RefreshCw className="w-4 h-4 animate-spin" />
          ) : (
            <Sparkles className="w-4 h-4 text-amber-300" />
          )}
          <span>{isGeneratingTip ? 'Consulting Gemini AI...' : 'Generate AI Custom Tip'}</span>
        </button>
      </div>

      {/* Search & Bookmark Filter Controls */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search health tips, nutrition, workouts..."
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-sm"
          />
        </div>

        <button
          onClick={() => setShowBookmarksOnly(!showBookmarksOnly)}
          className={`px-4 py-2.5 rounded-2xl text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm shrink-0 ${
            showBookmarksOnly
              ? 'bg-amber-500 text-white'
              : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-amber-400'
          }`}
        >
          <Bookmark className={`w-4 h-4 ${showBookmarksOnly ? 'fill-white' : 'text-amber-500'}`} />
          <span>Bookmarks ({bookmarkedIds.length})</span>
        </button>
      </div>

      {/* Category Pills */}
      <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
        {categories.map(cat => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-4 py-1.5 rounded-full text-xs font-semibold capitalize transition-all shrink-0 ${
              selectedCategory === cat.id
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-emerald-500'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Tips Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredTips.length === 0 ? (
          <div className="col-span-full py-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800">
            <Lightbulb className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
            <p className="text-sm font-medium text-slate-600 dark:text-slate-400">
              No health tips found matching criteria.
            </p>
            <p className="text-xs text-slate-400 mt-1">Try clearing your search query or generate an AI tip.</p>
          </div>
        ) : (
          filteredTips.map(tip => {
            const isBookmarked = bookmarkedIds.includes(tip.id);

            return (
              <motion.div
                key={tip.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                className="rounded-3xl p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between space-y-3 relative hover:shadow-md transition-all"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                        {tip.category}
                      </span>
                      {tip.isAiGenerated && (
                        <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-teal-500" /> AI Generated
                        </span>
                      )}
                    </div>
                    <button
                      onClick={() => toggleBookmarkTip(tip.id)}
                      className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-amber-500 transition-colors"
                      title="Bookmark Tip"
                    >
                      <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-amber-500 text-amber-500' : ''}`} />
                    </button>
                  </div>

                  <h3 className="font-bold text-base text-slate-900 dark:text-slate-100 leading-snug">
                    {tip.title}
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-1.5 leading-relaxed">
                    {tip.content}
                  </p>
                </div>

                {/* Actionable Step Box */}
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-100 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-900 dark:text-slate-100">Action Step:</strong> {tip.actionStep}
                  </div>
                </div>
              </motion.div>
            );
          })
        )}
      </div>
    </div>
  );
};
