import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Pill, Plus, CheckCircle2, Clock, Trash2, Bell, AlertCircle, X } from 'lucide-react';
import { useHealthData } from '../providers/HealthDataProvider';
import { Medication, MedicineFrequency } from '../models';
import { NotificationService } from '../services/notificationService';

export const MedicineScreen: React.FC = () => {
  const { medications, toggleMedicineTaken, addMedication, deleteMedication, addToast } = useHealthData();

  const [filter, setFilter] = useState<'all' | 'pending' | 'taken'>('all');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);

  // Form State for new medication
  const [name, setName] = useState<string>('');
  const [dosage, setDosage] = useState<string>('1 Tablet');
  const [time, setTime] = useState<string>('08:00');
  const [frequency, setFrequency] = useState<MedicineFrequency>('daily');
  const [instructions, setInstructions] = useState<'before_food' | 'after_food' | 'with_food' | 'anytime'>('after_food');
  const [color, setColor] = useState<string>('emerald');

  const activeMeds = medications.filter(m => m.active);
  const takenCount = activeMeds.filter(m => m.takenToday).length;
  const totalCount = activeMeds.length;
  const adherencePercent = totalCount > 0 ? Math.round((takenCount / totalCount) * 100) : 100;

  const filteredMeds = activeMeds.filter(m => {
    if (filter === 'pending') return !m.takenToday;
    if (filter === 'taken') return m.takenToday;
    return true;
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    addMedication({
      name,
      dosage,
      time,
      frequency,
      instructions,
      color,
      icon: 'Pill',
      active: true,
    });

    setName('');
    setShowAddModal(false);
  };

  const requestNotifications = async () => {
    const granted = await NotificationService.requestPermission();
    if (granted) {
      addToast('Notifications Enabled 🔔', 'You will receive reminders for scheduled medications.', 'success');
      NotificationService.sendNotification('Medicine Reminders Active 💊', {
        body: 'VitalPulse will alert you at your scheduled medication times.',
      });
    } else {
      addToast('Notification Alert', 'Browser push notification permission was not granted.', 'warning');
    }
  };

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Pill className="w-6 h-6 text-emerald-500" />
            Medicine Reminder
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Never miss a dose. Track schedules and intake history.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={requestNotifications}
            className="px-3 py-2 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-all"
            title="Enable Browser Push Reminders"
          >
            <Bell className="w-4 h-4 text-emerald-500" />
            <span>Enable Reminders</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md shadow-emerald-600/20 active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Add Medicine</span>
          </button>
        </div>
      </div>

      {/* Adherence Progress Card */}
      <div className="rounded-3xl p-5 bg-gradient-to-r from-teal-500/10 to-emerald-500/10 border border-emerald-500/20 flex items-center justify-between gap-4">
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-300">
            Today's Adherence Score
          </h3>
          <div className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 mt-1">
            {takenCount} of {totalCount} Taken ({adherencePercent}%)
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            {adherencePercent === 100 ? 'Great job! All medications completed today.' : 'Keep up with your scheduled health routine.'}
          </p>
        </div>
        <div className="relative w-14 h-14 flex items-center justify-center shrink-0">
          <svg className="w-full h-full transform -rotate-90">
            <circle cx="28" cy="28" r="22" stroke="currentColor" strokeWidth="4" className="text-slate-200 dark:text-slate-800" fill="transparent" />
            <circle
              cx="28"
              cy="28"
              r="22"
              stroke="currentColor"
              strokeWidth="4"
              className="text-emerald-500 transition-all duration-700"
              fill="transparent"
              strokeDasharray={138}
              strokeDashoffset={138 - (138 * adherencePercent) / 100}
              strokeLinecap="round"
            />
          </svg>
          <span className="absolute font-bold text-xs text-slate-900 dark:text-slate-100">{adherencePercent}%</span>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs w-fit">
        {(['all', 'pending', 'taken'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setFilter(tab)}
            className={`px-4 py-1.5 rounded-xl font-semibold capitalize transition-all ${
              filter === tab
                ? 'bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-400 shadow-sm'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Medication List */}
      <div className="space-y-3">
        {filteredMeds.length === 0 ? (
          <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800">
            <Pill className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
            <p className="text-sm font-medium text-slate-600 dark:text-slate-400">
              No medications found in this view.
            </p>
            <p className="text-xs text-slate-400 mt-1">Click "Add Medicine" above to schedule a new pill or vitamin.</p>
          </div>
        ) : (
          filteredMeds.map(med => (
            <motion.div
              key={med.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`p-4 rounded-3xl bg-white dark:bg-slate-900 border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                med.takenToday
                  ? 'border-emerald-200 dark:border-emerald-900/40 bg-emerald-50/20 dark:bg-emerald-950/10'
                  : 'border-slate-200/80 dark:border-slate-800'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 mt-0.5 ${
                  med.takenToday
                    ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400'
                    : 'bg-teal-50 dark:bg-slate-800 text-teal-600 dark:text-teal-400'
                }`}>
                  <Pill className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">{med.name}</h3>
                    <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                      {med.dosage}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 dark:text-slate-400 mt-1">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      {med.time}
                    </span>
                    <span>• {med.frequency.replace('_', ' ')}</span>
                    <span>• {med.instructions.replace('_', ' ')}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-center">
                <button
                  onClick={() => toggleMedicineTaken(med.id)}
                  className={`px-4 py-2 rounded-2xl text-xs font-semibold flex items-center gap-1.5 transition-all active:scale-95 ${
                    med.takenToday
                      ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800'
                      : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-md shadow-emerald-600/20'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{med.takenToday ? 'Dose Taken ✓' : 'Mark Taken'}</span>
                </button>
                <button
                  onClick={() => deleteMedication(med.id)}
                  className="p-2 rounded-2xl text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                  title="Delete Medication"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))
        )}
      </div>

      {/* Add Medication Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/50 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <h3 className="font-bold text-base text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <Pill className="w-5 h-5 text-emerald-500" />
                  Add New Medication
                </h3>
                <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleAddSubmit} className="space-y-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Medication Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="e.g. Vitamin D3, Amoxicillin, Aspirin"
                    className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-slate-100"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Dosage</label>
                    <input
                      type="text"
                      required
                      value={dosage}
                      onChange={e => setDosage(e.target.value)}
                      placeholder="e.g. 1 Tablet, 10ml"
                      className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-slate-100"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Reminder Time</label>
                    <input
                      type="time"
                      required
                      value={time}
                      onChange={e => setTime(e.target.value)}
                      className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-slate-100"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Frequency</label>
                    <select
                      value={frequency}
                      onChange={e => setFrequency(e.target.value as MedicineFrequency)}
                      className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-slate-100"
                    >
                      <option value="daily">Daily</option>
                      <option value="twice_daily">Twice Daily</option>
                      <option value="weekly">Weekly</option>
                      <option value="as_needed">As Needed</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Instructions</label>
                    <select
                      value={instructions}
                      onChange={e => setInstructions(e.target.value as any)}
                      className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-slate-100"
                    >
                      <option value="after_food">After Food</option>
                      <option value="before_food">Before Food</option>
                      <option value="with_food">With Food</option>
                      <option value="anytime">Anytime</option>
                    </select>
                  </div>
                </div>

                <div className="pt-3 flex gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="flex-1 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-md shadow-emerald-600/20"
                  >
                    Save Medication
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
