import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User as FirebaseUser,
  onAuthStateChanged,
  signInWithPopup,
  signOut as firebaseSignOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
} from 'firebase/auth';
import { auth, googleProvider } from '../services/firebase';
import { UserProfile } from '../models';
import { LocalStorageService, DEFAULT_USER_PROFILE } from '../services/localStorageService';
import { FirestoreService } from '../services/firestoreService';

interface AuthContextType {
  user: UserProfile | null;
  firebaseUser: FirebaseUser | null;
  loading: boolean;
  loginWithGoogle: () => Promise<void>;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  signupWithEmail: (name: string, email: string, pass: string) => Promise<void>;
  logout: () => Promise<void>;
  updateUserProfile: (data: Partial<UserProfile>) => Promise<void>;
  isGuest: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [user, setUser] = useState<UserProfile | null>(() => LocalStorageService.getProfile());
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);
      if (fbUser) {
        // Try fetching remote profile from Firestore
        const remoteProfile = await FirestoreService.fetchUserProfile(fbUser.uid);
        if (remoteProfile) {
          setUser(remoteProfile);
          LocalStorageService.saveProfile(remoteProfile);
        } else {
          // Create new user profile from firebase auth user
          const newProfile: UserProfile = {
            ...DEFAULT_USER_PROFILE,
            uid: fbUser.uid,
            name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Health User',
            email: fbUser.email || 'user@vitalpulse.ai',
            photoURL: fbUser.photoURL || undefined,
            isGuest: false,
          };
          setUser(newProfile);
          LocalStorageService.saveProfile(newProfile);
          await FirestoreService.saveUserProfile(newProfile);
        }
      } else {
        // Use local fallback guest profile
        const local = LocalStorageService.getProfile();
        setUser(local);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const loginWithGoogle = async () => {
    try {
      setLoading(true);
      await signInWithPopup(auth, googleProvider);
    } catch (err: any) {
      console.error('Google Login Error:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const loginWithEmail = async (email: string, pass: string) => {
    try {
      setLoading(true);
      await signInWithEmailAndPassword(auth, email, pass);
    } catch (err: any) {
      console.error('Email Login Error:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const signupWithEmail = async (name: string, email: string, pass: string) => {
    try {
      setLoading(true);
      const res = await createUserWithEmailAndPassword(auth, email, pass);
      if (res.user) {
        await updateProfile(res.user, { displayName: name });
        const newProf: UserProfile = {
          ...DEFAULT_USER_PROFILE,
          uid: res.user.uid,
          name,
          email,
          isGuest: false,
        };
        setUser(newProf);
        LocalStorageService.saveProfile(newProf);
        await FirestoreService.saveUserProfile(newProf);
      }
    } catch (err: any) {
      console.error('Signup Error:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    try {
      await firebaseSignOut(auth);
      // Revert to guest profile
      const guest = { ...DEFAULT_USER_PROFILE, isGuest: true };
      setUser(guest);
      LocalStorageService.saveProfile(guest);
    } catch (err) {
      console.error('Logout error:', err);
    }
  };

  const updateUserProfile = async (data: Partial<UserProfile>) => {
    if (!user) return;
    const updated = { ...user, ...data };
    setUser(updated);
    LocalStorageService.saveProfile(updated);
    if (!updated.isGuest) {
      await FirestoreService.saveUserProfile(updated);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        firebaseUser,
        loading,
        loginWithGoogle,
        loginWithEmail,
        signupWithEmail,
        logout,
        updateUserProfile,
        isGuest: !!user?.isGuest,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
