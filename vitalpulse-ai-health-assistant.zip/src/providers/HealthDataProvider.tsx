import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  BmiRecord,
  ChatMessage,
  HealthTip,
  Medication,
  TipCategory,
  WaterDayLog,
  WaterEntry,
} from '../models';
import { LocalStorageService, DEFAULT_TIPS } from '../services/localStorageService';
import { sendHealthChatMessage, fetchAiDailyTip } from '../services/geminiService';
import { NotificationService } from '../services/notificationService';
import { FirestoreService } from '../services/firestoreService';
import { useAuth } from './AuthProvider';

export type DeviceFrameType = 'responsive' | 'iphone' | 'android';

interface ToastMessage {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'info' | 'warning' | 'error';
}

interface HealthDataContextType {
  // Water state
  waterLog: WaterDayLog;
  addWaterEntry: (amountMl: number) => void;
  updateWaterGoal: (newGoalMl: number) => void;
  resetWaterLog: () => void;

  // Medicine state
  medications: Medication[];
  toggleMedicineTaken: (medId: string) => void;
  addMedication: (med: Omit<Medication, 'id' | 'takenToday'>) => void;
  deleteMedication: (medId: string) => void;

  // BMI state
  bmiHistory: BmiRecord[];
  addBmiRecord: (heightCm: number, weightKg: number, notes?: string) => BmiRecord;

  // Chat state
  chatMessages: ChatMessage[];
  isChatLoading: boolean;
  sendChatMessage: (content: string) => Promise<void>;
  clearChatHistory: () => void;

  // Tips state
  tips: HealthTip[];
  bookmarkedIds: string[];
  toggleBookmarkTip: (id: string) => void;
  generateAiTip: (category?: TipCategory) => Promise<void>;
  isGeneratingTip: boolean;

  // Device frame
  deviceFrame: DeviceFrameType;
  setDeviceFrame: (frame: DeviceFrameType) => void;

  // Health Score (0-100)
  healthScore: number;

  // Toast notifications
  toasts: ToastMessage[];
  addToast: (title: string, message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  removeToast: (id: string) => void;
}

const HealthDataContext = createContext<HealthDataContextType | undefined>(undefined);

export const HealthDataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();

  // Water State
  const [waterLog, setWaterLog] = useState<WaterDayLog>(() => LocalStorageService.getWaterLogToday());

  // Medicine State
  const [medications, setMedications] = useState<Medication[]>(() => LocalStorageService.getMedications());

  // BMI State
  const [bmiHistory, setBmiHistory] = useState<BmiRecord[]>(() => LocalStorageService.getBmiHistory());

  // Chat State
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => LocalStorageService.getChatMessages());
  const [isChatLoading, setIsChatLoading] = useState<boolean>(false);

  // Tips State
  const [tips, setTips] = useState<HealthTip[]>(DEFAULT_TIPS);
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(() => LocalStorageService.getBookmarkedTipIds());
  const [isGeneratingTip, setIsGeneratingTip] = useState<boolean>(false);

  // Frame switcher state
  const [deviceFrame, setDeviceFrameState] = useState<DeviceFrameType>('responsive');

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (title: string, message: string, type: 'success' | 'info' | 'warning' | 'error' = 'info') => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 5);
    setToasts(prev => [...prev.slice(-3), { id, title, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Water functions
  const addWaterEntry = (amountMl: number) => {
    const newEntry: WaterEntry = {
      id: Date.now().toString(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      amountMl,
    };
    const updatedLog: WaterDayLog = {
      ...waterLog,
      totalMl: waterLog.totalMl + amountMl,
      entries: [newEntry, ...waterLog.entries],
    };
    setWaterLog(updatedLog);
    LocalStorageService.saveWaterLogToday(updatedLog);
    NotificationService.playChime('water');

    if (updatedLog.totalMl >= updatedLog.goalMl && waterLog.totalMl < updatedLog.goalMl) {
      addToast('Hydration Goal Met! 🎉', `Awesome job! You reached your daily goal of ${updatedLog.goalMl} ml!`, 'success');
      NotificationService.sendNotification('Hydration Goal Reached! 🎉', {
        body: `Congratulations! You drank ${updatedLog.totalMl} ml today!`,
      });
    } else {
      addToast('Hydration Updated', `Added ${amountMl} ml of water. (${updatedLog.totalMl}/${updatedLog.goalMl} ml)`, 'info');
    }

    if (user?.uid) {
      FirestoreService.saveWaterLog(user.uid, updatedLog);
    }
  };

  const updateWaterGoal = (newGoalMl: number) => {
    const updated = { ...waterLog, goalMl: newGoalMl };
    setWaterLog(updated);
    LocalStorageService.saveWaterLogToday(updated);
    addToast('Water Goal Updated', `Your daily water target is now ${newGoalMl} ml.`, 'success');
  };

  const resetWaterLog = () => {
    const reset = { ...waterLog, totalMl: 0, entries: [] };
    setWaterLog(reset);
    LocalStorageService.saveWaterLogToday(reset);
    addToast('Water Log Reset', 'Today\'s water intake log has been reset.', 'warning');
  };

  // Medication functions
  const toggleMedicineTaken = (medId: string) => {
    const updatedMeds = medications.map(med => {
      if (med.id === medId) {
        const nextState = !med.takenToday;
        if (nextState) {
          NotificationService.playChime('medicine');
          addToast('Medicine Taken 💊', `Marked ${med.name} as taken for today.`, 'success');
        }
        return {
          ...med,
          takenToday: nextState,
          lastTakenAt: nextState ? new Date().toISOString() : med.lastTakenAt,
        };
      }
      return med;
    });

    setMedications(updatedMeds);
    LocalStorageService.saveMedications(updatedMeds);

    if (user?.uid) {
      FirestoreService.saveMedications(user.uid, updatedMeds);
    }
  };

  const addMedication = (newMedData: Omit<Medication, 'id' | 'takenToday'>) => {
    const newMed: Medication = {
      ...newMedData,
      id: `med-${Date.now()}`,
      takenToday: false,
    };
    const updated = [newMed, ...medications];
    setMedications(updated);
    LocalStorageService.saveMedications(updated);
    addToast('Medication Added', `${newMed.name} added to your reminder schedule.`, 'success');

    if (user?.uid) {
      FirestoreService.saveMedications(user.uid, updated);
    }
  };

  const deleteMedication = (medId: string) => {
    const filtered = medications.filter(m => m.id !== medId);
    setMedications(filtered);
    LocalStorageService.saveMedications(filtered);
    addToast('Medication Removed', 'Selected medication removed from your schedule.', 'info');

    if (user?.uid) {
      FirestoreService.saveMedications(user.uid, filtered);
    }
  };

  // BMI functions
  const addBmiRecord = (heightCm: number, weightKg: number, notes?: string): BmiRecord => {
    const heightM = heightCm / 100;
    const bmiVal = Number((weightKg / (heightM * heightM)).toFixed(1));

    let category: 'underweight' | 'normal' | 'overweight' | 'obese' = 'normal';
    if (bmiVal < 18.5) category = 'underweight';
    else if (bmiVal <= 24.9) category = 'normal';
    else if (bmiVal <= 29.9) category = 'overweight';
    else category = 'obese';

    const record: BmiRecord = {
      id: `bmi-${Date.now()}`,
      date: new Date().toISOString(),
      heightCm,
      weightKg,
      bmi: bmiVal,
      category,
      notes,
    };

    const updated = LocalStorageService.saveBmiRecord(record);
    setBmiHistory(updated);
    addToast('BMI Logged', `Your BMI is ${bmiVal} (${category.toUpperCase()}).`, 'success');

    if (user?.uid) {
      FirestoreService.saveBmiRecord(user.uid, record);
    }

    return record;
  };

  // Chat functions
  const sendChatMessage = async (content: string) => {
    if (!content.trim()) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      content,
      timestamp: new Date().toISOString(),
    };

    const updatedHistory = [...chatMessages, userMsg];
    setChatMessages(updatedHistory);
    LocalStorageService.saveChatMessages(updatedHistory);
    setIsChatLoading(true);

    // Context from user stats
    const latestBmi = bmiHistory[0]?.bmi;
    const latestBmiCat = bmiHistory[0]?.category;

    const userCtx = {
      age: user?.age,
      gender: user?.gender,
      height: user?.heightCm,
      weight: user?.weightKg,
      bmi: latestBmi,
      bmiCategory: latestBmiCat,
      conditions: user?.medicalConditions?.join(', ') || 'None',
    };

    try {
      const replyText = await sendHealthChatMessage(updatedHistory, userCtx);

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        content: replyText,
        timestamp: new Date().toISOString(),
      };

      const finalMessages = [...updatedHistory, aiMsg];
      setChatMessages(finalMessages);
      LocalStorageService.saveChatMessages(finalMessages);
      NotificationService.playChime('chat');
    } catch (error) {
      console.error('Chat error:', error);
      addToast('Chat Warning', 'Could not get response from AI. Please retry.', 'error');
    } finally {
      setIsChatLoading(false);
    }
  };

  const clearChatHistory = () => {
    const initial = [
      {
        id: 'msg-1',
        role: 'assistant' as const,
        content: 'Hello! Chat history cleared. How can I assist you with your health today?',
        timestamp: new Date().toISOString(),
      },
    ];
    setChatMessages(initial);
    LocalStorageService.saveChatMessages(initial);
    addToast('Chat Cleared', 'Conversation history reset.', 'info');
  };

  // Tip functions
  const toggleBookmarkTip = (tipId: string) => {
    const updatedIds = LocalStorageService.toggleBookmarkTip(tipId);
    setBookmarkedIds(updatedIds);

    const isNowBookmarked = updatedIds.includes(tipId);
    addToast(
      isNowBookmarked ? 'Tip Bookmarked' : 'Bookmark Removed',
      isNowBookmarked ? 'Saved to your bookmarked health tips.' : 'Removed from bookmarks.',
      'info'
    );
  };

  const generateAiTip = async (category: TipCategory = 'all') => {
    setIsGeneratingTip(true);
    addToast('Generating AI Tip', 'Asking Gemini for a custom wellness tip...', 'info');

    try {
      const aiTip = await fetchAiDailyTip(category, {
        waterLog: waterLog.totalMl,
        bmi: bmiHistory[0]?.bmi,
      });

      const newTipObj: HealthTip = {
        id: `ai-tip-${Date.now()}`,
        title: aiTip.title || 'Personalized Health Tip',
        category: (aiTip.category as TipCategory) || 'nutrition',
        content: aiTip.content || 'Stay active and hydrated throughout your day.',
        actionStep: aiTip.actionStep || 'Drink a glass of water right now.',
        icon: aiTip.icon || 'Sparkles',
        readTime: '1 min',
        isBookmarked: false,
        isAiGenerated: true,
      };

      setTips(prev => [newTipObj, ...prev]);
      addToast('AI Tip Ready! ✨', newTipObj.title, 'success');
    } catch (e) {
      addToast('Error', 'Failed to generate custom tip.', 'error');
    } finally {
      setIsGeneratingTip(false);
    }
  };

  // Dynamic Health Score calculation (0 - 100)
  const calculateHealthScore = (): number => {
    let score = 50; // base

    // Water score (+25 max)
    const waterRatio = Math.min(1, waterLog.totalMl / (waterLog.goalMl || 2500));
    score += Math.round(waterRatio * 25);

    // Medicine score (+15 max)
    const activeMeds = medications.filter(m => m.active);
    if (activeMeds.length > 0) {
      const takenCount = activeMeds.filter(m => m.takenToday).length;
      score += Math.round((takenCount / activeMeds.length) * 15);
    } else {
      score += 15; // default full marks if no meds required
    }

    // BMI score (+10 max)
    const latestBmi = bmiHistory[0];
    if (latestBmi) {
      if (latestBmi.category === 'normal') score += 10;
      else if (latestBmi.category === 'underweight' || latestBmi.category === 'overweight') score += 6;
      else score += 3;
    }

    return Math.min(100, Math.max(0, score));
  };

  const healthScore = calculateHealthScore();

  return (
    <HealthDataContext.Provider
      value={{
        waterLog,
        addWaterEntry,
        updateWaterGoal,
        resetWaterLog,
        medications,
        toggleMedicineTaken,
        addMedication,
        deleteMedication,
        bmiHistory,
        addBmiRecord,
        chatMessages,
        isChatLoading,
        sendChatMessage,
        clearChatHistory,
        tips,
        bookmarkedIds,
        toggleBookmarkTip,
        generateAiTip,
        isGeneratingTip,
        deviceFrame,
        setDeviceFrame: setDeviceFrameState,
        healthScore,
        toasts,
        addToast,
        removeToast,
      }}
    >
      {children}
    </HealthDataContext.Provider>
  );
};

export const useHealthData = (): HealthDataContextType => {
  const context = useContext(HealthDataContext);
  if (!context) {
    throw new Error('useHealthData must be used within a HealthDataProvider');
  }
  return context;
};
