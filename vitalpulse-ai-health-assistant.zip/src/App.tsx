import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ThemeProvider } from './providers/ThemeProvider';
import { AuthProvider } from './providers/AuthProvider';
import { HealthDataProvider } from './providers/HealthDataProvider';
import { Header } from './widgets/Header';
import { Navbar, ScreenTab } from './widgets/Navbar';
import { ToastContainer } from './widgets/Toast';
import { MedicalDisclaimerBanner } from './widgets/MedicalDisclaimerBanner';
import { DeviceFrame } from './widgets/DeviceFrame';

import { HomeScreen } from './screens/HomeScreen';
import { ChatScreen } from './screens/ChatScreen';
import { BMIScreen } from './screens/BMIScreen';
import { MedicineScreen } from './screens/MedicineScreen';
import { WaterScreen } from './screens/WaterScreen';
import { TipsScreen } from './screens/TipsScreen';
import { ProfileScreen } from './screens/ProfileScreen';

export function App() {
  const [activeTab, setActiveTab] = useState<ScreenTab>('home');

  const renderScreen = () => {
    switch (activeTab) {
      case 'home':
        return <HomeScreen setActiveTab={setActiveTab} />;
      case 'chat':
        return <ChatScreen />;
      case 'bmi':
        return <BMIScreen />;
      case 'medicine':
        return <MedicineScreen />;
      case 'water':
        return <WaterScreen />;
      case 'tips':
        return <TipsScreen />;
      case 'profile':
        return <ProfileScreen />;
      default:
        return <HomeScreen setActiveTab={setActiveTab} />;
    }
  };

  return (
    <ThemeProvider>
      <AuthProvider>
        <HealthDataProvider>
          <DeviceFrame>
            {/* Top Medical Disclaimer Safety Banner */}
            <MedicalDisclaimerBanner />

            {/* Application Header Bar */}
            <Header onNavigateProfile={() => setActiveTab('profile')} />

            {/* Animated Screen Content */}
            <main className="min-h-[calc(100vh-140px)]">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.2 }}
                >
                  {renderScreen()}
                </motion.div>
              </AnimatePresence>
            </main>

            {/* Bottom Flutter-style Mobile Navbar */}
            <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

            {/* Global Animated Toast Alerts */}
            <ToastContainer />
          </DeviceFrame>
        </HealthDataProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
