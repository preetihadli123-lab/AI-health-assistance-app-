// Clean Architecture Data Models for VitalPulse AI Health Assistant

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  photoURL?: string;
  age: number;
  gender: 'male' | 'female' | 'other' | 'prefer_not_to_say';
  heightCm: number; // In cm
  weightKg: number; // In kg
  bloodGroup: string;
  allergies: string[];
  medicalConditions: string[];
  unitSystem: 'metric' | 'imperial';
  dailyWaterGoalMl: number;
  dailyStepGoal: number;
  dailySleepGoalHours: number;
  isGuest?: boolean;
  createdAt: string;
}

export type BmiCategoryType = 'underweight' | 'normal' | 'overweight' | 'obese';

export interface BmiCategoryInfo {
  type: BmiCategoryType;
  label: string;
  color: string; // Tailwind color class or hex
  description: string;
  recommendations: string[];
  minBmi: number;
  maxBmi: number;
}

export interface BmiRecord {
  id: string;
  date: string;
  heightCm: number;
  weightKg: number;
  bmi: number;
  category: BmiCategoryType;
  notes?: string;
}

export type MedicineFrequency = 'daily' | 'twice_daily' | 'weekly' | 'as_needed';

export interface Medication {
  id: string;
  name: string;
  dosage: string; // e.g. "1 Tablet", "10 ml", "500 mg"
  time: string; // "08:00"
  frequency: MedicineFrequency;
  instructions: 'before_food' | 'after_food' | 'with_food' | 'anytime';
  color: string; // Pill visual color tag
  icon: string; // Pill, Bottle, Capsule, Injection
  takenToday: boolean;
  lastTakenAt?: string;
  active: boolean;
}

export interface DoseLog {
  id: string;
  medicationId: string;
  medicationName: string;
  timestamp: string;
  status: 'taken' | 'skipped' | 'snoozed';
}

export interface WaterEntry {
  id: string;
  timestamp: string;
  amountMl: number;
}

export interface WaterDayLog {
  date: string; // YYYY-MM-DD
  totalMl: number;
  goalMl: number;
  entries: WaterEntry[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  isAudioAvailable?: boolean;
}

export interface HealthPrompt {
  id: string;
  title: string;
  prompt: string;
  category: 'symptom' | 'nutrition' | 'fitness' | 'wellness' | 'sleep';
  icon: string;
}

export type TipCategory = 'all' | 'nutrition' | 'fitness' | 'mental' | 'sleep' | 'heart';

export interface HealthTip {
  id: string;
  title: string;
  category: TipCategory;
  content: string;
  actionStep: string;
  icon: string;
  readTime: string;
  isBookmarked?: boolean;
  isAiGenerated?: boolean;
}
