import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  query,
  getDocs,
} from 'firebase/firestore';
import { db, auth } from './firebase';
import { UserProfile, BmiRecord, Medication, WaterDayLog } from '../models';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid,
      email: auth?.currentUser?.email,
      emailVerified: auth?.currentUser?.emailVerified,
      isAnonymous: auth?.currentUser?.isAnonymous,
    },
    operationType,
    path,
  };
  console.error('Firestore Error context: ', JSON.stringify(errInfo));
  return errInfo;
}

export const FirestoreService = {
  async saveUserProfile(profile: UserProfile): Promise<boolean> {
    if (!auth.currentUser || profile.isGuest) return false;
    const userPath = `users/${profile.uid}`;
    try {
      await setDoc(doc(db, userPath), {
        ...profile,
        updatedAt: new Date().toISOString(),
      }, { merge: true });
      return true;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, userPath);
      return false;
    }
  },

  async fetchUserProfile(uid: string): Promise<UserProfile | null> {
    const userPath = `users/${uid}`;
    try {
      const snap = await getDoc(doc(db, userPath));
      if (snap.exists()) {
        return snap.data() as UserProfile;
      }
      return null;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, userPath);
      return null;
    }
  },

  async saveBmiRecord(uid: string, record: BmiRecord): Promise<boolean> {
    if (!uid || uid.startsWith('guest_')) return false;
    const path = `users/${uid}/bmi_history/${record.id}`;
    try {
      await setDoc(doc(db, path), record);
      return true;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
      return false;
    }
  },

  async saveMedications(uid: string, medications: Medication[]): Promise<boolean> {
    if (!uid || uid.startsWith('guest_')) return false;
    const path = `users/${uid}/medications/active_list`;
    try {
      await setDoc(doc(db, path), { items: medications, updatedAt: new Date().toISOString() });
      return true;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
      return false;
    }
  },

  async saveWaterLog(uid: string, waterLog: WaterDayLog): Promise<boolean> {
    if (!uid || uid.startsWith('guest_')) return false;
    const path = `users/${uid}/water_logs/${waterLog.date}`;
    try {
      await setDoc(doc(db, path), waterLog);
      return true;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
      return false;
    }
  }
};
