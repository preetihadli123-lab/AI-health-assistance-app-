import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
import { getAuth, Auth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore, Firestore, doc, getDocFromServer } from 'firebase/firestore';

// Default config fallback for dev mode preview
const defaultFirebaseConfig = {
  apiKey: "AIzaSyDummyKeyForStudioPreviewModeOnly",
  authDomain: "vitalpulse-health.firebaseapp.com",
  projectId: "vitalpulse-health",
  storageBucket: "vitalpulse-health.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:dummy123456"
};

let app: FirebaseApp;
let auth: Auth;
let db: Firestore;

try {
  // Check if firebase app already initialized
  if (!getApps().length) {
    app = initializeApp(defaultFirebaseConfig);
  } else {
    app = getApps()[0];
  }
  auth = getAuth(app);
  db = getFirestore(app);
} catch (err) {
  console.warn("Firebase initialization warning (using fallback mock context):", err);
  app = getApps()[0] || initializeApp(defaultFirebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
}

export const googleProvider = new GoogleAuthProvider();

// Connection check verification helper as mandated by firebase skill
export async function testFirestoreConnection() {
  try {
    if (db) {
      await getDocFromServer(doc(db, 'test', 'connection'));
    }
  } catch (error: any) {
    if (error instanceof Error && error.message.includes('client is offline')) {
      console.warn("Firestore offline mode active.");
    }
  }
}

export { app, auth, db };
