import { ChatMessage, HealthTip, TipCategory, UserProfile } from '../models';

export async function sendHealthChatMessage(
  messages: ChatMessage[],
  userContext?: Partial<UserProfile> & { bmi?: number; bmiCategory?: string }
): Promise<string> {
  try {
    const response = await fetch('/api/health/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        messages,
        userContext,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || `Server error: ${response.status}`);
    }

    const data = await response.json();
    return data.reply;
  } catch (error: any) {
    console.error('geminiService sendHealthChatMessage error:', error);
    return `I am having trouble connecting to the AI health service right now (${error.message || 'Network error'}). Please ensure your internet connection is active and try again.`;
  }
}

export async function fetchAiDailyTip(
  category: TipCategory = 'nutrition',
  userStats?: { waterLog?: number; bmi?: number }
): Promise<Partial<HealthTip>> {
  try {
    const response = await fetch('/api/health/daily-tip', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        category,
        userStats,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to fetch AI tip');
    }

    return await response.json();
  } catch (error) {
    console.error('fetchAiDailyTip error:', error);
    return {
      title: 'Mindful Morning Hydration',
      category: 'nutrition',
      content: 'Drinking 500ml of room temperature water immediately after waking up kickstarts your metabolism and restores hydration levels after overnight rest.',
      actionStep: 'Keep a glass or water bottle near your bed for tomorrow morning.',
      icon: 'Droplet',
    };
  }
}
