import {
  BmiRecord,
  ChatMessage,
  HealthTip,
  Medication,
  UserProfile,
  WaterDayLog,
} from '../models';

const STORAGE_KEYS = {
  USER_PROFILE: 'vitalpulse_user_profile',
  BMI_HISTORY: 'vitalpulse_bmi_history',
  MEDICATIONS: 'vitalpulse_medications',
  WATER_LOG: 'vitalpulse_water_log',
  CHAT_MESSAGES: 'vitalpulse_chat_messages',
  BOOKMARKED_TIPS: 'vitalpulse_bookmarked_tips',
  THEME_MODE: 'vitalpulse_theme_mode',
  DEVICE_FRAME: 'vitalpulse_device_frame',
};

export const DEFAULT_USER_PROFILE: UserProfile = {
  uid: 'guest_user_101',
  name: 'Alex Rivera',
  email: 'alex.rivera@example.com',
  age: 28,
  gender: 'male',
  heightCm: 175,
  weightKg: 68,
  bloodGroup: 'O+',
  allergies: ['Penicillin', 'Peanuts'],
  medicalConditions: ['Mild Asthma'],
  unitSystem: 'metric',
  dailyWaterGoalMl: 2500,
  dailyStepGoal: 8000,
  dailySleepGoalHours: 8,
  isGuest: true,
  createdAt: new Date().toISOString(),
};

export const INITIAL_MEDICATIONS: Medication[] = [
  {
    id: 'med-1',
    name: 'Multivitamin Formula',
    dosage: '1 Tablet',
    time: '08:00',
    frequency: 'daily',
    instructions: 'after_food',
    color: 'emerald',
    icon: 'Pill',
    takenToday: true,
    lastTakenAt: new Date().toISOString(),
    active: true,
  },
  {
    id: 'med-2',
    name: 'Omega-3 Fish Oil',
    dosage: '1 Capsule',
    time: '13:00',
    frequency: 'daily',
    instructions: 'with_food',
    color: 'amber',
    icon: 'Capsule',
    takenToday: false,
    active: true,
  },
  {
    id: 'med-3',
    name: 'Hydration Electrolytes',
    dosage: '1 Sachet',
    time: '18:00',
    frequency: 'as_needed',
    instructions: 'anytime',
    color: 'cyan',
    icon: 'Bottle',
    takenToday: false,
    active: true,
  },
];

export const INITIAL_BMI_HISTORY: BmiRecord[] = [
  {
    id: 'bmi-1',
    date: new Date(Date.now() - 30 * 86400000).toISOString(),
    heightCm: 175,
    weightKg: 72,
    bmi: 23.5,
    category: 'normal',
    notes: 'Initial check',
  },
  {
    id: 'bmi-2',
    date: new Date(Date.now() - 15 * 86400000).toISOString(),
    heightCm: 175,
    weightKg: 70,
    bmi: 22.9,
    category: 'normal',
    notes: 'Progress check',
  },
  {
    id: 'bmi-3',
    date: new Date().toISOString(),
    heightCm: 175,
    weightKg: 68,
    bmi: 22.2,
    category: 'normal',
    notes: 'Current weight',
  },
];

export const DEFAULT_TIPS: HealthTip[] = [
  {
    id: 'tip-1',
    title: 'Optimal Water Intake Timing',
    category: 'nutrition',
    content: 'Drink 1 glass of water 30 minutes before meals to aid digestion and help control calorie intake naturally.',
    actionStep: 'Drink 250ml water before your next main meal.',
    icon: 'Droplet',
    readTime: '1 min',
    isBookmarked: true,
  },
  {
    id: 'tip-2',
    title: 'The 20-20-20 Eye Strain Rule',
    category: 'wellness' as any,
    content: 'Every 20 minutes spent looking at a screen, look at an object 20 feet away for at least 20 seconds to reduce ocular fatigue.',
    actionStep: 'Look away from your screen right now at something far across the room.',
    icon: 'Sun',
    readTime: '2 min',
    isBookmarked: false,
  },
  {
    id: 'tip-3',
    title: 'Cardio Intervals for Heart Health',
    category: 'heart',
    content: 'Alternating 1 minute of brisk high-intensity walking with 2 minutes of moderate walking improves cardiovascular endurance faster than constant pace.',
    actionStep: 'Incorporate 3 high-intensity interval bursts into your evening walk.',
    icon: 'Activity',
    readTime: '3 min',
    isBookmarked: false,
  },
  {
    id: 'tip-4',
    title: 'Screen-Free Wind Down for Better Sleep',
    category: 'sleep',
    content: 'Blue light suppresses melatonin production. Stopping screen usage 45 minutes before sleep increases deep REM sleep duration dramatically.',
    actionStep: 'Set a phone shutdown alarm 1 hour before bedtime.',
    icon: 'Moon',
    readTime: '2 min',
    isBookmarked: true,
  },
];

export const INITIAL_CHAT: ChatMessage[] = [
  {
    id: 'msg-1',
    role: 'assistant',
    content: 'Hello! I am **VitalPulse AI**, your personal health & wellness companion powered by Google Gemini.\n\nI can answer health questions, offer nutrition tips, help evaluate lifestyle habits, and guide you on fitness wellness.\n\n*How can I support your health goals today?*',
    timestamp: new Date().toISOString(),
  },
];

export const LocalStorageService = {
  getProfile(): UserProfile {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);
      return data ? JSON.parse(data) : DEFAULT_USER_PROFILE;
    } catch {
      return DEFAULT_USER_PROFILE;
    }
  },

  saveProfile(profile: UserProfile): void {
    try {
      localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile));
    } catch (e) {
      console.error('Error saving profile:', e);
    }
  },

  getBmiHistory(): BmiRecord[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.BMI_HISTORY);
      return data ? JSON.parse(data) : INITIAL_BMI_HISTORY;
    } catch {
      return INITIAL_BMI_HISTORY;
    }
  },

  saveBmiRecord(record: BmiRecord): BmiRecord[] {
    const history = this.getBmiHistory();
    const updated = [record, ...history];
    try {
      localStorage.setItem(STORAGE_KEYS.BMI_HISTORY, JSON.stringify(updated));
    } catch (e) {
      console.error('Error saving BMI history:', e);
    }
    return updated;
  },

  getMedications(): Medication[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.MEDICATIONS);
      return data ? JSON.parse(data) : INITIAL_MEDICATIONS;
    } catch {
      return INITIAL_MEDICATIONS;
    }
  },

  saveMedications(meds: Medication[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.MEDICATIONS, JSON.stringify(meds));
    } catch (e) {
      console.error('Error saving medications:', e);
    }
  },

  getWaterLogToday(): WaterDayLog {
    const todayStr = new Date().toISOString().split('T')[0];
    try {
      const data = localStorage.getItem(`${STORAGE_KEYS.WATER_LOG}_${todayStr}`);
      if (data) return JSON.parse(data);
    } catch {
      // Fallback below
    }
    const profile = this.getProfile();
    return {
      date: todayStr,
      totalMl: 1250, // default starter intake for today
      goalMl: profile.dailyWaterGoalMl || 2500,
      entries: [
        { id: 'w1', timestamp: '08:30 AM', amountMl: 250 },
        { id: 'w2', timestamp: '11:15 AM', amountMl: 500 },
        { id: 'w3', timestamp: '02:00 PM', amountMl: 500 },
      ],
    };
  },

  saveWaterLogToday(log: WaterDayLog): void {
    const todayStr = new Date().toISOString().split('T')[0];
    try {
      localStorage.setItem(`${STORAGE_KEYS.WATER_LOG}_${todayStr}`, JSON.stringify(log));
    } catch (e) {
      console.error('Error saving water log:', e);
    }
  },

  getChatMessages(): ChatMessage[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CHAT_MESSAGES);
      return data ? JSON.parse(data) : INITIAL_CHAT;
    } catch {
      return INITIAL_CHAT;
    }
  },

  saveChatMessages(messages: ChatMessage[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.CHAT_MESSAGES, JSON.stringify(messages));
    } catch (e) {
      console.error('Error saving chat messages:', e);
    }
  },

  getBookmarkedTipIds(): string[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.BOOKMARKED_TIPS);
      return data ? JSON.parse(data) : ['tip-1', 'tip-4'];
    } catch {
      return ['tip-1', 'tip-4'];
    }
  },

  toggleBookmarkTip(tipId: string): string[] {
    const ids = this.getBookmarkedTipIds();
    const exists = ids.includes(tipId);
    const updated = exists ? ids.filter(id => id !== tipId) : [...ids, tipId];
    try {
      localStorage.setItem(STORAGE_KEYS.BOOKMARKED_TIPS, JSON.stringify(updated));
    } catch (e) {
      console.error('Error toggling bookmark:', e);
    }
    return updated;
  },
};
