import React from 'react';
import { useHealthData } from '../providers/HealthDataProvider';
import { Wifi, Battery, Signal } from 'lucide-react';

interface DeviceFrameProps {
  children: React.ReactNode;
}

export const DeviceFrame: React.FC<DeviceFrameProps> = ({ children }) => {
  const { deviceFrame } = useHealthData();

  if (deviceFrame === 'responsive') {
    return <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 pb-20">{children}</div>;
  }

  const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-2 sm:p-6 transition-colors">
      <div className="text-center mb-3 text-slate-400 text-xs hidden sm:block">
        Viewing in <span className="text-emerald-400 font-semibold uppercase">{deviceFrame} Mobile Frame</span> mode. Click "Web" in the header anytime for full width.
      </div>

      {/* Mobile Device Mockup */}
      <div className="w-full max-w-[420px] h-[860px] max-h-[92vh] bg-slate-900 border-[10px] border-slate-800 rounded-[48px] shadow-2xl overflow-hidden relative flex flex-col ring-1 ring-slate-700">
        {/* Dynamic Island / iPhone Notch */}
        <div className="h-10 bg-white dark:bg-slate-900 px-6 flex items-center justify-between text-slate-900 dark:text-slate-100 text-xs font-semibold z-40 select-none shrink-0 border-b border-slate-100 dark:border-slate-800/50">
          <span>{currentTime}</span>
          {deviceFrame === 'iphone' ? (
            <div className="w-24 h-5 bg-slate-950 rounded-full mx-auto" />
          ) : (
            <div className="w-3.5 h-3.5 bg-slate-950 rounded-full" />
          )}
          <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
            <Signal className="w-3 h-3" />
            <Wifi className="w-3 h-3" />
            <Battery className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* Scrollable Screen Content */}
        <div className="flex-1 overflow-y-auto bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 pb-20 relative">
          {children}
        </div>

        {/* Bottom Phone Bar indicator */}
        <div className="h-4 bg-white dark:bg-slate-900 flex items-center justify-center z-40 shrink-0">
          <div className="w-32 h-1 bg-slate-300 dark:bg-slate-700 rounded-full" />
        </div>
      </div>
    </div>
  );
};
