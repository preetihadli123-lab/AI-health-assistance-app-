import React from 'react';
import { motion } from 'motion/react';

interface HealthCardProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
  actionIcon?: React.ReactNode;
  onAction?: () => void;
  className?: string;
  gradient?: string;
}

export const HealthCard: React.FC<HealthCardProps> = ({
  children,
  title,
  subtitle,
  actionIcon,
  onAction,
  className = '',
  gradient,
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className={`rounded-3xl p-4 sm:p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition-all ${gradient || ''} ${className}`}
    >
      {(title || actionIcon) && (
        <div className="flex items-center justify-between mb-3 gap-2">
          <div>
            {title && <h3 className="font-bold text-base text-slate-900 dark:text-slate-100 tracking-tight">{title}</h3>}
            {subtitle && <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{subtitle}</p>}
          </div>
          {actionIcon && (
            <button
              onClick={onAction}
              className="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors"
            >
              {actionIcon}
            </button>
          )}
        </div>
      )}
      {children}
    </motion.div>
  );
};
