import React from 'react';
import { Activity, Moon, Sun, Smartphone, Monitor } from 'lucide-react';
import { useTheme } from '../providers/ThemeProvider';
import { useHealthData } from '../providers/HealthDataProvider';
import { useAuth } from '../providers/AuthProvider';

interface HeaderProps {
  onNavigateProfile: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onNavigateProfile }) => {
  const { isDarkMode, toggleTheme } = useTheme();
  const { deviceFrame, setDeviceFrame, healthScore } = useHealthData();
  const { user } = useAuth();

  return (
    <header className="sticky top-0 z-30 bg-white/85 dark:bg-slate-900/85 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800/80 px-4 py-3 transition-colors">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
        {/* Brand logo & title */}
        <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-white shadow-md shadow-emerald-500/20">
            <Activity className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-base tracking-tight text-slate-900 dark:text-slate-100 font-sans">
                Vital<span className="text-emerald-500">Pulse</span>
              </span>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 px-1.5 py-0.5 rounded-full border border-emerald-300 dark:border-emerald-800">
                AI Health
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 hidden sm:block">
              Personal Wellness Companion
            </p>
          </div>
        </div>

        {/* Center / Controls */}
        <div className="flex items-center gap-2">
          {/* Health Score Pill */}
          <div
            className="hidden xs:flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-default"
            title="AI Health Score based on daily hydration, meds, sleep & BMI"
          >
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span>Score:</span>
            <span className="font-bold text-emerald-600 dark:text-emerald-400">{healthScore}</span>
            <span className="text-[10px] text-slate-400">/100</span>
          </div>

          {/* Device Frame Switcher (Mobile App Preview Toggle) */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700 text-xs">
            <button
              onClick={() => setDeviceFrame('responsive')}
              className={`p-1.5 rounded-lg transition-all flex items-center gap-1 ${
                deviceFrame === 'responsive'
                  ? 'bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-400 shadow-sm font-medium'
                  : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
              }`}
              title="Fluid Web View"
            >
              <Monitor className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Web</span>
            </button>
            <button
              onClick={() => setDeviceFrame('iphone')}
              className={`p-1.5 rounded-lg transition-all flex items-center gap-1 ${
                deviceFrame === 'iphone'
                  ? 'bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-400 shadow-sm font-medium'
                  : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
              }`}
              title="iOS App Frame"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden md:inline">iOS App</span>
            </button>
          </div>

          {/* Theme Toggle Button */}
          <button
            onClick={toggleTheme}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
            title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label="Toggle theme"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-700" />}
          </button>

          {/* User Avatar */}
          <button
            onClick={onNavigateProfile}
            className="w-9 h-9 rounded-xl bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold text-sm hover:scale-105 active:scale-95 transition-all"
            title="User Profile"
          >
            {user?.name ? user.name.charAt(0).toUpperCase() : 'A'}
          </button>
        </div>
      </div>
    </header>
  );
};
