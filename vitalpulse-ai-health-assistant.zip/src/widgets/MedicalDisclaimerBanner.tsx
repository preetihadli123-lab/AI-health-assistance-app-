import React, { useState } from 'react';
import { ShieldAlert, X } from 'lucide-react';

export const MedicalDisclaimerBanner: React.FC = () => {
  const [dismissed, setDismissed] = useState<boolean>(false);

  if (dismissed) return null;

  return (
    <div className="bg-amber-500/10 dark:bg-amber-500/15 border-b border-amber-500/20 px-4 py-2 text-xs text-amber-900 dark:text-amber-200 flex items-center justify-between gap-2">
      <div className="flex items-center gap-2 min-w-0">
        <ShieldAlert className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
        <p className="truncate sm:whitespace-normal">
          <strong className="font-semibold">Medical Disclaimer:</strong> VitalPulse AI provides general health information only and is not a substitute for professional medical advice, diagnosis, or treatment.
        </p>
      </div>
      <button
        onClick={() => setDismissed(true)}
        className="p-1 text-amber-700 dark:text-amber-400 hover:text-amber-900 dark:hover:text-amber-100 shrink-0 rounded"
        title="Dismiss disclaimer"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};
